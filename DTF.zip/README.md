# DTF

Delphi training framework(DTF)는 델파이를 잘 사용할 수 있도록 기능들을 조합한 예시(샘플) 및 개발 프레임워크입니다.

![MDIClient](./Docs/Images/DTFClient.png)
